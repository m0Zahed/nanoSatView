import { Eye, Satellite } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router';
import { motion } from 'motion/react';
import { Button } from '@/app/components/ui/button';

export function ViewPage() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[#1a1a1a] relative">
      {/* Film Grain Texture */}
      <div 
        className="fixed inset-0 opacity-[0.15] pointer-events-none z-50 mix-blend-overlay"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#1a1a1a]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
              <Satellite className="h-8 w-8 text-gray-300" />
              <span className="text-xl font-bold text-white font-mono tracking-wider">nanoSat</span>
            </div>
            <div className="flex items-center gap-2 ml-4">
              <Button
                variant="ghost"
                className="text-gray-300 hover:text-white hover:bg-white/5 font-mono rounded-none"
                onClick={() => navigate('/systems')}
              >
                Systems
              </Button>
              <Button
                variant="ghost"
                className="font-mono rounded-none text-white"
                onClick={() => navigate('/view')}
              >
                <motion.span
                  animate={{
                    textShadow: [
                      '0 0 10px rgba(255,255,255,0.8)',
                      '0 0 20px rgba(255,255,255,0.4)',
                      '0 0 10px rgba(255,255,255,0.8)',
                    ]
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  View
                </motion.span>
              </Button>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              className="text-gray-300 hover:text-white hover:bg-white/5 border border-white/20"
              onClick={() => navigate('/dashboard')}
            >
              Dashboard
            </Button>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center pt-20 relative overflow-hidden">
        <div className="text-center relative z-10">
          <div className="inline-flex items-center justify-center w-24 h-24 mb-6 border border-white/10 bg-[#222222]">
            <Eye className="h-12 w-12 text-gray-400" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-3" style={{ fontFamily: 'serif' }}>
            View
          </h1>
          <p className="text-gray-400 font-mono text-sm max-w-md">
            Visualization and monitoring interface coming soon
          </p>
        </div>
      </div>
    </div>
  );
}