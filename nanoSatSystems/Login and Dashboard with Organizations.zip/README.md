
  # Login and Dashboard with Organizations

  This is a code bundle for Login and Dashboard with Organizations. The original project is available at https://www.figma.com/design/VJ26WtmzJcH6cOpxGXOGiQ/Login-and-Dashboard-with-Organizations.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  